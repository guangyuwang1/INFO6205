package edu.neu.coe.info6205.graphs.gis;

import edu.neu.coe.info6205.graphs.undirected.Position;

public interface GeoPoint {
    String getName();

    Position getPosition();
}
