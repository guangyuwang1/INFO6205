package edu.neu.coe.info6205.util;

import edu.neu.coe.info6205.sort.elementary.InsertionSort;

import java.util.Arrays;

import edu.neu.coe.info6205.util.Timer;
public class insertionSortTimeTest {
    public static void main(String[] args) {
        InsertionSort ins = new InsertionSort();
        Integer[] ranArr = new Integer[5000];
        for (int i = 0; i < ranArr.length; i++) {
            ranArr[i] = ((int) (Math.random() * 2000));
        }
        Integer[] sortArr = new Integer[5000];
        for (int i = 0; i < ranArr.length; i++) {
            sortArr[i] = ((int) (Math.random() * 2000));
        }
        Arrays.sort(sortArr);
        Integer[] partArr = new Integer[5000];
        for (int i = 0; i < sortArr.length / 2; i++) {
            partArr[i] = sortArr[i];
        }
        for (int i = ranArr.length / 2; i < sortArr.length; i++) {
            partArr[i] = ranArr[i];
        }
        Integer[] reverseArr = new Integer[5000];
        for (int i = sortArr.length - 1; i >= 0; i--) {
            reverseArr[sortArr.length - i - 1] = sortArr[i];
        }


        Timer timer = new Timer();
        final int zzz = 20;
        final double ranTime = timer.repeat(10, () -> zzz, t -> {
            ins.sort(ranArr, 0, ranArr.length - 1);
            return null;
        });
        final double sortTime = timer.repeat(10, () -> zzz, t -> {
            ins.sort(sortArr, 0, sortArr.length - 1);
            return null;
        });
        final double partTime = timer.repeat(10, () -> zzz, t -> {
            ins.sort(partArr, 0, partArr.length - 1);
            return null;
        });
        final double reverseTime = timer.repeat(10, () -> zzz, t -> {
            ins.sort(reverseArr, 0, reverseArr.length - 1);
            return null;
        });
        System.out.println("The insertion sort time of random number group with length 5000 is "+ranTime);
        System.out.println("The insertion sort time of an ordered array of length 5000 is "+sortTime);
        System.out.println("The insertion sort time of an partially-ordered  array of length 5000 is "+partTime);
        System.out.println("The insertion sort time of an reverse-ordered  array of length 5000 is "+reverseTime);

    }
}
